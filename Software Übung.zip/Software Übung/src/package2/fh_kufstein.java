package package2;

public class fh_kufstein {
    public static void main(String[] args) {
        System.out.println("FH Kufstein Tirol");
    }
}
